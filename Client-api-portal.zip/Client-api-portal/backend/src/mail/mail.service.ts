// src/mail/mail.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as nodemailer from 'nodemailer';
import { Client } from '../clients/schemas/client.schema';

@Injectable()
export class MailService {
  private readonly logger = new Logger(MailService.name);
  private transporter: nodemailer.Transporter;

  constructor(private config: ConfigService) {
    // ── Office 365 SMTP transport ──
    this.transporter = nodemailer.createTransport({
      host: config.get<string>('SMTP_HOST', 'smtp.office365.com'),
      port: config.get<number>('SMTP_PORT', 587),
      secure: false,        // STARTTLS on port 587
      requireTLS: true,     // Force TLS upgrade
      auth: {
        user: config.get<string>('SMTP_USER'),
        pass: config.get<string>('SMTP_PASS'),
      },
      tls: {
        ciphers: 'SSLv3',
        rejectUnauthorized: false, // set true in production with valid certs
      },
    });
  }

  // ─────────────────────────────────────────────────────────
  // EMAIL 1: Notify Apigee team to create app credentials
  // Triggered when: a new client is registered
  // Sent to: APIGEE_TEAM_EMAIL
  // ─────────────────────────────────────────────────────────
  async sendApigeeCreationRequest(client: Client & { _id: any }): Promise<void> {
    const portalUrl = this.config.get<string>('PORTAL_URL', 'http://localhost:3000');
    const to = this.config.get<string>('APIGEE_TEAM_EMAIL');

    const subject = `[ACTION REQUIRED] Create Apigee App Creds — ${client.organizationName}`;

    const html = this.wrapEmail(`
      <div class="header-banner apigee">
        <div class="header-icon">⚙</div>
        <div>
          <div class="header-title">Apigee App Creation Required</div>
          <div class="header-sub">New client onboarding request</div>
        </div>
      </div>

      <p class="greeting">Hi Apigee Team,</p>
      <p class="body-text">
        A new external client has been registered on the API Portal and requires
        an Apigee X application to be created. Please create the app credentials
        as soon as possible so we can proceed with onboarding.
      </p>

      <div class="info-card">
        <div class="info-card-title">📋 Client Details</div>
        <table class="detail-table">
          <tr><td class="label">Organization</td><td class="value">${client.organizationName}</td></tr>
          <tr><td class="label">Domain</td><td class="value">${client.domain}</td></tr>
          <tr><td class="label">Technical Contact</td><td class="value">${client.contactName}</td></tr>
          <tr><td class="label">Contact Email</td><td class="value">${client.contactEmail}</td></tr>
          <tr><td class="label">API Product</td><td class="value">${client.apiProduct}</td></tr>
          <tr><td class="label">Environment</td><td class="value">${client.environment}</td></tr>
          <tr><td class="label">Client ID (Portal)</td><td class="value mono">${client._id}</td></tr>
          ${client.notes ? `<tr><td class="label">Notes</td><td class="value">${client.notes}</td></tr>` : ''}
        </table>
      </div>

      <div class="action-card">
        <div class="action-title">✅ Action Required</div>
        <ol class="action-list">
          <li>Log into <strong>Apigee X Console</strong></li>
          <li>Create a new app for <strong>${client.organizationName}</strong></li>
          <li>Assign product: <strong>${client.apiProduct}</strong></li>
          <li>Set environment: <strong>${client.environment}</strong></li>
          <li>Return to the portal and enter the generated Client ID &amp; App ID</li>
        </ol>
      </div>

      <div style="text-align:center;margin:28px 0">
        <a href="${portalUrl}/clients/${client._id}" class="cta-button">
          Open Client in Portal →
        </a>
      </div>

      <p class="body-text">
        Once you've created the credentials, please update the client status in the portal
        so the next onboarding step (mTLS cert collection) can begin automatically.
      </p>
    `);

    await this.send({ to, subject, html, client, type: 'APIGEE_CREATION_REQUEST' });
  }

  // ─────────────────────────────────────────────────────────
  // EMAIL 2: Notify Akamai team to onboard the mTLS cert
  // Triggered when: client submits their mTLS certificate
  // Sent to: AKAMAI_TEAM_EMAIL
  // ─────────────────────────────────────────────────────────
  async sendAkamaiOnboardingRequest(client: Client & { _id: any }): Promise<void> {
    const portalUrl = this.config.get<string>('PORTAL_URL', 'http://localhost:3000');
    const to = this.config.get<string>('AKAMAI_TEAM_EMAIL');

    const subject = `[ACTION REQUIRED] Onboard mTLS Certificate — ${client.organizationName}`;

    const html = this.wrapEmail(`
      <div class="header-banner akamai">
        <div class="header-icon">🔐</div>
        <div>
          <div class="header-title">mTLS Certificate Onboarding Required</div>
          <div class="header-sub">Client certificate ready for Akamai onboarding</div>
        </div>
      </div>

      <p class="greeting">Hi Akamai Team,</p>
      <p class="body-text">
        A client certificate has been received from <strong>${client.organizationName}</strong>
        and is ready to be onboarded into Akamai for mutual TLS authentication.
        Please process this at your earliest convenience.
      </p>

      <div class="info-card">
        <div class="info-card-title">📋 Client Details</div>
        <table class="detail-table">
          <tr><td class="label">Organization</td><td class="value">${client.organizationName}</td></tr>
          <tr><td class="label">Domain</td><td class="value">${client.domain}</td></tr>
          <tr><td class="label">API Product</td><td class="value">${client.apiProduct}</td></tr>
          <tr><td class="label">Environment</td><td class="value">${client.environment}</td></tr>
          <tr><td class="label">Apigee App ID</td><td class="value mono">${client.apigeeAppId || 'Pending'}</td></tr>
        </table>
      </div>

      <div class="info-card cert-card">
        <div class="info-card-title">🔑 Certificate Details</div>
        <table class="detail-table">
          ${client.certSubject ? `<tr><td class="label">Subject</td><td class="value mono">${client.certSubject}</td></tr>` : ''}
          ${client.certFingerprint ? `<tr><td class="label">SHA256 Fingerprint</td><td class="value mono fingerprint">${client.certFingerprint}</td></tr>` : ''}
          ${client.certExpiresAt ? `<tr><td class="label">Expires</td><td class="value">${new Date(client.certExpiresAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</td></tr>` : ''}
          <tr><td class="label">Received At</td><td class="value">${new Date().toLocaleString()}</td></tr>
        </table>

        ${client.certPem ? `
        <div class="cert-block-label">PEM Certificate</div>
        <div class="cert-block">${client.certPem}</div>
        ` : ''}
      </div>

      <div class="action-card">
        <div class="action-title">✅ Action Required</div>
        <ol class="action-list">
          <li>Log into the <strong>Akamai Control Center</strong></li>
          <li>Navigate to <strong>Security → Client Certificates</strong></li>
          <li>Upload the PEM certificate above for <strong>${client.organizationName}</strong></li>
          <li>Associate it with the <strong>${client.apiProduct}</strong> property</li>
          <li>Create a support ticket and reply to this email with the <strong>Akamai Ticket ID</strong></li>
          <li>Update the portal once onboarding is confirmed complete</li>
        </ol>
      </div>

      <div style="text-align:center;margin:28px 0">
        <a href="${portalUrl}/clients/${client._id}" class="cta-button akamai-btn">
          Open Client in Portal →
        </a>
      </div>

      <div class="warning-box">
        ⚠ Please reply to this email with your Akamai ticket number so the API team
        can track progress. The client is waiting on this step to go live.
      </div>
    `);

    await this.send({ to, subject, html, client, type: 'AKAMAI_ONBOARDING_REQUEST' });
  }

  // ─────────────────────────────────────────────────────────
  // EMAIL 3: Notify internal team that Apigee creds are done
  // Triggered when: Apigee team marks creds as created
  // Sent to: INTERNAL_TEAM_EMAIL
  // ─────────────────────────────────────────────────────────
  async sendApigeeCredsConfirmation(client: Client & { _id: any }): Promise<void> {
    const portalUrl = this.config.get<string>('PORTAL_URL', 'http://localhost:3000');
    const to = this.config.get<string>('INTERNAL_TEAM_EMAIL');

    const subject = `[INFO] Apigee Creds Created — ${client.organizationName} — Awaiting mTLS Cert`;

    const html = this.wrapEmail(`
      <div class="header-banner success">
        <div class="header-icon">✅</div>
        <div>
          <div class="header-title">Apigee App Credentials Created</div>
          <div class="header-sub">Next step: collect mTLS certificate from client</div>
        </div>
      </div>

      <p class="greeting">Hi API Team,</p>
      <p class="body-text">
        The Apigee app credentials for <strong>${client.organizationName}</strong>
        have been successfully created. The onboarding process is now at
        <strong>Step 3 — awaiting mTLS certificate</strong> from the client.
      </p>

      <div class="info-card">
        <div class="info-card-title">📋 Apigee App Details</div>
        <table class="detail-table">
          <tr><td class="label">Organization</td><td class="value">${client.organizationName}</td></tr>
          <tr><td class="label">Apigee App ID</td><td class="value mono">${client.apigeeAppId}</td></tr>
          <tr><td class="label">Client ID</td><td class="value mono">${client.apigeeClientId}</td></tr>
          <tr><td class="label">Environment</td><td class="value">${client.environment}</td></tr>
          <tr><td class="label">API Product</td><td class="value">${client.apiProduct}</td></tr>
        </table>
      </div>

      <div class="action-card">
        <div class="action-title">📧 Next Action</div>
        <ol class="action-list">
          <li>Email <strong>${client.contactName}</strong> (${client.contactEmail}) to request their mTLS certificate</li>
          <li>Remind them: PEM format, minimum 2048-bit, from a trusted CA</li>
          <li>Once received, upload the cert in the portal to auto-notify the Akamai team</li>
        </ol>
      </div>

      <div style="text-align:center;margin:28px 0">
        <a href="${portalUrl}/clients/${client._id}" class="cta-button">
          View Client in Portal →
        </a>
      </div>
    `);

    await this.send({ to, subject, html, client, type: 'APIGEE_CREDS_CONFIRMED' });
  }

  // ─────────────────────────────────────────────────────────
  // SHARED: send + log
  // ─────────────────────────────────────────────────────────
  private async send(opts: {
    to: string;
    subject: string;
    html: string;
    client: Client & { _id: any };
    type: string;
  }): Promise<void> {
    const from = this.config.get<string>('MAIL_FROM', 'API Portal <noreply@yourcompany.com>');
    try {
      await this.transporter.sendMail({ from, to: opts.to, subject: opts.subject, html: opts.html });
      this.logger.log(`✉ Email sent [${opts.type}] → ${opts.to}`);

      // Push to client's email log (caller must save the client doc)
      opts.client.emailLog.push({
        to: opts.to,
        subject: opts.subject,
        sentAt: new Date(),
        type: opts.type,
      });
    } catch (err) {
      this.logger.error(`✘ Failed to send email [${opts.type}] → ${opts.to}: ${err.message}`);
      throw err;
    }
  }

  // ─────────────────────────────────────────────────────────
  // HTML wrapper — shared styled shell for all emails
  // ─────────────────────────────────────────────────────────
  private wrapEmail(body: string): string {
    return `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:#f0f2f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
  .wrapper { max-width:620px; margin:32px auto; background:#ffffff; border-radius:10px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,0.08); }
  .top-bar { height:4px; background:linear-gradient(90deg, #0066cc, #00aadd, #00d4ff); }
  .content { padding:32px; }

  /* Header banners */
  .header-banner { display:flex; align-items:center; gap:16px; padding:20px 24px; border-radius:8px; margin-bottom:24px; }
  .header-banner.apigee { background:linear-gradient(135deg, #0d1b2a, #1a3a5c); }
  .header-banner.akamai { background:linear-gradient(135deg, #0d2414, #1a4a2a); }
  .header-banner.success { background:linear-gradient(135deg, #0d2414, #1a4a2a); }
  .header-icon { font-size:32px; flex-shrink:0; }
  .header-title { font-size:17px; font-weight:700; color:#ffffff; line-height:1.2; }
  .header-sub { font-size:12px; color:rgba(255,255,255,0.6); margin-top:3px; }

  /* Text */
  .greeting { font-size:15px; font-weight:600; color:#1a1a2e; margin-bottom:10px; }
  .body-text { font-size:14px; color:#4a5568; line-height:1.65; margin-bottom:20px; }

  /* Detail cards */
  .info-card { background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:20px; margin-bottom:20px; }
  .info-card-title { font-size:12px; font-weight:700; text-transform:uppercase; letter-spacing:0.08em; color:#64748b; margin-bottom:14px; }
  .detail-table { width:100%; border-collapse:collapse; }
  .detail-table tr:not(:last-child) td { padding-bottom:10px; }
  .label { font-size:12px; color:#64748b; width:140px; vertical-align:top; padding-top:1px; }
  .value { font-size:13px; color:#1a202c; font-weight:500; }
  .mono { font-family: 'Courier New', monospace; font-size:12px; color:#2563eb; word-break:break-all; }
  .fingerprint { font-size:10px; color:#64748b; }

  /* Certificate block */
  .cert-card { border-color:#bbf7d0; background:#f0fdf4; }
  .cert-block-label { font-size:11px; font-weight:600; color:#166534; margin:14px 0 6px; text-transform:uppercase; letter-spacing:0.06em; }
  .cert-block { background:#ffffff; border:1px solid #bbf7d0; border-radius:6px; padding:12px; font-family:'Courier New',monospace; font-size:10px; color:#166534; word-break:break-all; line-height:1.5; max-height:180px; overflow:hidden; }

  /* Action card */
  .action-card { background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:20px; margin-bottom:20px; }
  .action-title { font-size:13px; font-weight:700; color:#1d4ed8; margin-bottom:12px; }
  .action-list { padding-left:20px; }
  .action-list li { font-size:13px; color:#1e3a5f; margin-bottom:8px; line-height:1.5; }

  /* Warning box */
  .warning-box { background:#fffbeb; border:1px solid #fde68a; border-radius:6px; padding:14px 16px; font-size:12px; color:#92400e; line-height:1.6; margin-top:16px; }

  /* CTA button */
  .cta-button { display:inline-block; background:#0066cc; color:#ffffff !important; text-decoration:none; padding:12px 28px; border-radius:6px; font-size:14px; font-weight:600; letter-spacing:0.02em; }
  .akamai-btn { background:#16a34a; }

  /* Footer */
  .footer { background:#f8fafc; border-top:1px solid #e2e8f0; padding:20px 32px; }
  .footer-text { font-size:11px; color:#94a3b8; line-height:1.6; }
  .footer-brand { font-weight:700; color:#64748b; }
</style>
</head>
<body>
<div class="wrapper">
  <div class="top-bar"></div>
  <div class="content">
    ${body}
  </div>
  <div class="footer">
    <p class="footer-text">
      <span class="footer-brand">API Client Portal</span> — Drug Price Platform<br>
      This is an automated notification. Do not reply directly to this email.<br>
      For questions, contact the API team at api-team@yourcompany.com
    </p>
  </div>
</div>
</body>
</html>`;
  }
}
