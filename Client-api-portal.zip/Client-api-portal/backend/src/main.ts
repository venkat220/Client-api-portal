// src/main.ts
import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const logger = new Logger('Bootstrap');

  // ── Global validation pipe — validates all DTOs ──
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,        // strip unknown properties
      forbidNonWhitelisted: false,
      transform: true,        // auto-transform types
    }),
  );

  // ── CORS — allow the frontend portal to call this API ──
  app.enableCors({
    origin: process.env.PORTAL_URL || 'http://localhost:4200',
    methods: ['GET', 'POST', 'PATCH', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  });

  const port = process.env.PORT || 3000;
  await app.listen(port);

  logger.log(`🚀 API Client Portal backend running on port ${port}`);
  logger.log(`📋 Endpoints: http://localhost:${port}/api/clients`);
}

bootstrap();
