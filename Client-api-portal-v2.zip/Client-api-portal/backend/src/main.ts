// src/main.ts
import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const logger = new Logger('Bootstrap');

  // Global validation pipe — validates all DTOs automatically
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: false,
      transform: true,
    }),
  );

  // CORS — allow the frontend portal to call this API
  // In production, set CORS_ORIGIN env var to your exact frontend domain
  app.enableCors({
    origin: process.env.CORS_ORIGIN || '*',
    methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: false,
  });

  const port = process.env.PORT || 3000;
  await app.listen(port);

  logger.log(`🚀 API Client Portal backend running on http://localhost:${port}`);
  logger.log(`📋 Clients API: http://localhost:${port}/api/clients`);
  logger.log(`📊 Pipeline:    http://localhost:${port}/api/clients/pipeline`);
}

bootstrap();
