# API Reference

Complete REST API reference for the Client API Portal backend.

Base URL: `http://localhost:3000` (development) | `https://your-domain.com` (production)

---

## Authentication

All endpoints are internal — protect with your corporate network / VPN or add a JWT guard.
No public auth is required by default; add `@nestjs/jwt` guards if you need per-user access control.

---

## Clients

### `GET /api/clients`
Returns all registered clients, sorted by most recent first.

**Query Parameters**

| Param   | Type   | Description                          |
|---------|--------|--------------------------------------|
| `stage` | string | Filter by onboarding stage (optional)|

**Example**
```http
GET /api/clients?stage=AKAMAI_PENDING
```

**Response `200`**
```json
[
  {
    "_id": "65f1a2b3c4d5e6f7a8b9c0d1",
    "organizationName": "Pharma Corp",
    "domain": "pharma-corp.com",
    "contactName": "Jane Smith",
    "contactEmail": "jane@pharma-corp.com",
    "apiProduct": "Drug Price API",
    "environment": "Production",
    "stage": "AKAMAI_PENDING",
    "status": "ONBOARDING",
    "apigeeAppId": "pc-prod-001",
    "apigeeClientId": "abc123",
    "certSubject": "CN=pharma-corp.com",
    "certFingerprint": "A3:F1:2B:...",
    "certExpiresAt": "2027-03-01T00:00:00.000Z",
    "akamaiTicketId": null,
    "stageTimestamps": { "REQUEST_RECEIVED": "2025-03-10T09:00:00Z" },
    "emailLog": [...],
    "createdAt": "2025-03-10T09:00:00.000Z",
    "updatedAt": "2025-03-11T14:30:00.000Z"
  }
]
```

---

### `GET /api/clients/pipeline`
Returns a count of clients at each onboarding stage. Used to populate dashboard stats.

**Response `200`**
```json
{
  "REQUEST_RECEIVED": 0,
  "APIGEE_PENDING": 2,
  "APIGEE_DONE": 0,
  "CERT_PENDING": 1,
  "CERT_RECEIVED": 0,
  "AKAMAI_PENDING": 1,
  "AKAMAI_DONE": 0,
  "LIVE": 18
}
```

---

### `GET /api/clients/:id`
Returns a single client by MongoDB ObjectId.

**Response `200`** — full client document (same shape as above)
**Response `404`** — client not found

---

### `POST /api/clients`
Register a new external client and kick off the onboarding process.

> **✉ Triggers email → Apigee Team:** "Please create app credentials for this client"

**Request Body**
```json
{
  "organizationName": "Pharma Corp",
  "domain": "pharma-corp.com",
  "contactName": "Jane Smith",
  "contactEmail": "jane@pharma-corp.com",
  "apiProduct": "Drug Price API",
  "environment": "Production",
  "notes": "Needs UAT sandbox first"
}
```

| Field              | Required | Description                         |
|--------------------|----------|-------------------------------------|
| `organizationName` | ✅       | Full legal name of the organization |
| `domain`           | ✅       | Primary domain                      |
| `contactName`      | ✅       | Technical contact full name         |
| `contactEmail`     | ✅       | Technical contact email             |
| `apiProduct`       | ✅       | e.g. `Drug Price API`               |
| `environment`      | ❌       | Default: `Production`               |
| `notes`            | ❌       | Any special requirements            |

**Response `201`** — created client document

---

### `PATCH /api/clients/:id/apigee-done`
Apigee team calls this endpoint once they have created the app credentials in Apigee X.

> **✉ Triggers email → Internal Team:** "Creds created, now collect mTLS cert from client"

**Request Body**
```json
{
  "apigeeAppId": "pc-prod-001",
  "apigeeClientId": "abc123clientid",
  "apigeeClientSecretRef": "secrets/pharma-corp/prod/client-secret",
  "notes": "Assigned to Drug Price API product"
}
```

> ⚠ `apigeeClientSecretRef` must be a **reference path** to your secrets manager (AWS Secrets Manager / Azure Key Vault). Never store raw secrets in MongoDB.

**Response `200`** — updated client document

---

### `PATCH /api/clients/:id/submit-cert`
Submit the client's mTLS certificate (received from the external client).

> **✉ Triggers email → Akamai Team:** "Certificate received, please onboard to mTLS"

**Request Body**
```json
{
  "certPem": "-----BEGIN CERTIFICATE-----\nMIIDXTCC...\n-----END CERTIFICATE-----",
  "certSubject": "CN=pharma-corp.com, O=Pharma Corp, C=US",
  "certFingerprint": "A3:F1:2B:4C:...",
  "certExpiresAt": "2027-03-01"
}
```

| Field              | Required | Description                              |
|--------------------|----------|------------------------------------------|
| `certPem`          | ✅       | Full PEM content of the x509 certificate |
| `certSubject`      | ❌       | Certificate subject DN                   |
| `certFingerprint`  | ❌       | SHA256 fingerprint for verification      |
| `certExpiresAt`    | ❌       | ISO date string for expiry tracking      |

**Response `200`** — updated client document

---

### `PATCH /api/clients/:id/akamai-done`
Akamai team calls this once the certificate has been successfully onboarded.

**Request Body**
```json
{
  "akamaiTicketId": "AK-2947",
  "notes": "Onboarded to drug-price-api production property"
}
```

**Response `200`** — updated client document with stage `AKAMAI_DONE`

---

### `PATCH /api/clients/:id/go-live`
Marks the client as fully onboarded. Sets `stage: LIVE` and `status: ACTIVE`.

**Request Body** — none required

**Response `200`** — updated client document

---

## Onboarding Stage Reference

| Stage              | Meaning                                    | Next Action                    |
|--------------------|--------------------------------------------|--------------------------------|
| `REQUEST_RECEIVED` | Client registered in portal                | Create Apigee app              |
| `APIGEE_PENDING`   | Waiting for Apigee team to create app      | Apigee team action             |
| `APIGEE_DONE`      | App credentials created                    | Request cert from client       |
| `CERT_PENDING`     | Waiting for client to submit mTLS cert     | Client action                  |
| `CERT_RECEIVED`    | Cert received, submitting to Akamai        | Auto-transitions               |
| `AKAMAI_PENDING`   | Cert submitted to Akamai for onboarding    | Akamai team action             |
| `AKAMAI_DONE`      | Akamai onboarding confirmed                | Deliver credentials to client  |
| `LIVE`             | Client fully onboarded and consuming APIs  | —                              |

---

## Error Responses

All errors follow this shape:

```json
{
  "statusCode": 400,
  "message": "Client is not in APIGEE_PENDING stage. Current stage: CERT_PENDING",
  "error": "Bad Request"
}
```

| Code | Meaning                                    |
|------|--------------------------------------------|
| 400  | Bad Request — wrong stage or invalid body  |
| 404  | Client not found                           |
| 500  | Internal server error (check SMTP config)  |
