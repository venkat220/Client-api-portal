// src/clients/schemas/client.schema.ts
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type ClientDocument = Client & Document;

// ── Onboarding step stages ──
export enum OnboardingStage {
  REQUEST_RECEIVED   = 'REQUEST_RECEIVED',   // Step 1 — client reached out
  APIGEE_PENDING     = 'APIGEE_PENDING',     // Step 2 — waiting for Apigee team to create app creds
  APIGEE_DONE        = 'APIGEE_DONE',        // Step 2 complete — app creds created
  CERT_PENDING       = 'CERT_PENDING',       // Step 3 — waiting for client to submit mTLS cert
  CERT_RECEIVED      = 'CERT_RECEIVED',      // Step 3 complete — cert received from client
  AKAMAI_PENDING     = 'AKAMAI_PENDING',     // Step 4 — cert submitted to Akamai, awaiting onboard
  AKAMAI_DONE        = 'AKAMAI_DONE',        // Step 4 complete — Akamai has onboarded the cert
  LIVE               = 'LIVE',               // Step 5 — credentials delivered, client is live
}

export enum ClientStatus {
  ONBOARDING = 'ONBOARDING',
  ACTIVE     = 'ACTIVE',
  BLOCKED    = 'BLOCKED',
  INACTIVE   = 'INACTIVE',
}

@Schema({ timestamps: true })
export class Client {
  // ── Organisation details ──
  @Prop({ required: true, trim: true })
  organizationName: string;

  @Prop({ required: true, trim: true, lowercase: true })
  domain: string;

  // ── Technical contact ──
  @Prop({ required: true })
  contactName: string;

  @Prop({ required: true, lowercase: true, trim: true })
  contactEmail: string;

  // ── API product ──
  @Prop({ required: true })
  apiProduct: string; // e.g. "Drug Price API"

  @Prop({ default: 'Production' })
  environment: string; // Production | UAT | Both

  // ── Apigee app credentials ──
  @Prop({ default: null })
  apigeeAppId: string | null;

  @Prop({ default: null })
  apigeeClientId: string | null;

  // NOTE: Never store raw client secrets in plain text in production.
  // Use a secrets manager (e.g. AWS Secrets Manager / Azure Key Vault).
  @Prop({ default: null })
  apigeeClientSecretRef: string | null; // reference/path to secret, not the value

  // ── mTLS Certificate ──
  @Prop({ default: null })
  certSubject: string | null;      // e.g. CN=pharma-corp.com

  @Prop({ default: null })
  certFingerprint: string | null;  // SHA256 fingerprint

  @Prop({ default: null })
  certExpiresAt: Date | null;

  @Prop({ default: null })
  certPem: string | null;          // PEM content submitted by client

  // ── Akamai ──
  @Prop({ default: null })
  akamaiTicketId: string | null;   // e.g. AK-2947

  // ── Onboarding state ──
  @Prop({ enum: OnboardingStage, default: OnboardingStage.REQUEST_RECEIVED })
  stage: OnboardingStage;

  @Prop({ enum: ClientStatus, default: ClientStatus.ONBOARDING })
  status: ClientStatus;

  @Prop({ default: null })
  notes: string | null;

  // ── Audit: track when each stage was completed ──
  @Prop({ type: Object, default: {} })
  stageTimestamps: Record<string, Date>;

  // ── Email notification log ──
  @Prop({ type: [Object], default: [] })
  emailLog: Array<{
    to: string;
    subject: string;
    sentAt: Date;
    type: string;
  }>;
}

export const ClientSchema = SchemaFactory.createForClass(Client);
