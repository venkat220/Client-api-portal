# Client API Portal

> End-to-end onboarding automation and API testing portal for the Drug Price API platform.
> Built for internal teams and external client developers.

![Status](https://img.shields.io/badge/status-active-brightgreen)
![Stack](https://img.shields.io/badge/backend-NestJS-red)
![DB](https://img.shields.io/badge/database-MongoDB-green)
![Email](https://img.shields.io/badge/email-Office%20365%20SMTP-blue)

---

## What This Does

External clients who want to consume the Drug Price API go through a multi-step
onboarding process involving your internal team, the Apigee team, and the Akamai team.
Previously this was all manual — emails flying between teams, no visibility, things getting lost.

**This portal automates it:**

| Before | After |
|--------|-------|
| Manual email to Apigee team | ✅ Auto-email fires when client is registered |
| Manual email to Akamai team | ✅ Auto-email fires when cert is submitted |
| No visibility into who's where | ✅ Live onboarding tracker with 5-step progress |
| Clients guessing how to integrate | ✅ Built-in developer docs + API flow tester |
| No audit trail | ✅ Full activity log with timestamps |

---

## Architecture

```
┌──────────────────────────────────────────────────────┐
│                  CLIENT API PORTAL                   │
├─────────────────────┬────────────────────────────────┤
│      FRONTEND       │           BACKEND              │
│                     │                                │
│  HTML/CSS/JS        │  NestJS 10                     │
│  Single-file SPA    │  MongoDB + Mongoose            │
│  ─────────────────  │  Nodemailer + Office 365 SMTP  │
│  • Dashboard        │  ─────────────────────────     │
│  • Onboarding       │  REST API                      │
│    Tracker          │  Email Automation              │
│  • API Tester       │  Onboarding State Machine      │
│  • Flow Viewer      │                                │
│  • Docs             │                                │
│  • Activity Log     │                                │
└─────────────────────┴────────────────────────────────┘
```

---

## Automated Email Flow

```
POST /api/clients  ──────────────► ✉ Apigee Team
"New client registered"              "Please create app credentials"
         │
         ▼
PATCH /:id/apigee-done  ─────────► ✉ Internal Team
"Creds created"                      "Now collect mTLS cert from client"
         │
         ▼
PATCH /:id/submit-cert  ─────────► ✉ Akamai Team
"Cert received"                      "Please onboard cert to mTLS"
         │
         ▼
PATCH /:id/akamai-done
         │
         ▼
PATCH /:id/go-live  ──────────────► Client is LIVE ✅
```

---

## API Call Chain (What Clients Consume)

```
Step 1: OAuth Token
  POST /oauth/v2/token
  → Returns: access_token

Step 2: Member Search
  POST /v1/member/search
  Headers: Authorization: Bearer {access_token}
  → Returns: memberToken

Step 3: Experience API
  GET /v1/drugprice/experience
  Headers: Authorization: Bearer {access_token}
           X-Member-Token: {memberToken}
  → Returns: Drug pricing data ✅
```

---

## Project Structure

```
Client-api-portal/
├── frontend/
│   └── index.html              # Single-file portal dashboard (HTML/CSS/JS)
│
├── backend/
│   ├── src/
│   │   ├── main.ts             # NestJS entry point
│   │   ├── app.module.ts       # Root module
│   │   ├── clients/
│   │   │   ├── schemas/
│   │   │   │   └── client.schema.ts    # MongoDB schema + onboarding stages
│   │   │   ├── dto/
│   │   │   │   ├── create-client.dto.ts
│   │   │   │   ├── submit-cert.dto.ts
│   │   │   │   └── update-stages.dto.ts
│   │   │   ├── clients.controller.ts   # REST endpoints
│   │   │   ├── clients.service.ts      # Business logic + email triggers
│   │   │   └── clients.module.ts
│   │   └── mail/
│   │       ├── mail.service.ts         # Nodemailer + all email templates
│   │       └── mail.module.ts
│   ├── .env.example            # All required environment variables
│   ├── package.json
│   ├── tsconfig.json
│   └── README.md               # Backend-specific setup guide
│
└── docs/
    ├── API_REFERENCE.md        # Full REST API documentation
    ├── EMAIL_NOTIFICATIONS.md  # Email templates + SMTP setup
    └── ONBOARDING_PROCESS.md   # Step-by-step onboarding guide
```

---

## Quick Start

### Prerequisites
- Node.js 18+
- MongoDB (local or Atlas)
- Office 365 email account

### 1. Clone the repo
```bash
git clone https://github.com/venkat220/Client-api-portal.git
cd Client-api-portal
```

### 2. Set up the backend
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your credentials (see below)
```

### 3. Configure `.env`
```env
# MongoDB
MONGODB_URI=mongodb://localhost:27017/api-client-portal

# Office 365 SMTP
SMTP_HOST=smtp.office365.com
SMTP_PORT=587
SMTP_USER=your-email@yourcompany.com
SMTP_PASS=your-app-password

# Team email addresses
MAIL_FROM="API Portal <noreply@yourcompany.com>"
INTERNAL_TEAM_EMAIL=api-team@yourcompany.com
APIGEE_TEAM_EMAIL=apigee-admin@yourcompany.com
AKAMAI_TEAM_EMAIL=akamai-team@yourcompany.com

# Portal URL (used in email links)
PORTAL_URL=http://localhost:3000
```

### 4. Start the backend
```bash
npm run start:dev
# Server: http://localhost:3000
```

### 5. Open the frontend
```bash
# Simply open frontend/index.html in your browser
# Or serve it:
npx serve frontend/
```

---

## Documentation

| Document | Description |
|----------|-------------|
| [API Reference](./docs/API_REFERENCE.md) | All REST endpoints with request/response examples |
| [Email Notifications](./docs/EMAIL_NOTIFICATIONS.md) | Email templates, triggers, and SMTP setup |
| [Onboarding Process](./docs/ONBOARDING_PROCESS.md) | Step-by-step onboarding guide with SLA targets |
| [Backend README](./backend/README.md) | Backend-specific setup, project structure, and notes |

---

## Tech Stack

| Layer | Technology | Why |
|-------|------------|-----|
| Backend framework | NestJS 10 | Structured, modular, TypeScript-first |
| Database | MongoDB + Mongoose | Flexible schema for evolving onboarding data |
| Email | Nodemailer + Office 365 | Works with existing corporate email |
| Validation | class-validator | DTO validation out of the box |
| Frontend | Vanilla HTML/CSS/JS | Zero build step, easy to deploy anywhere |

---

## Contributing

1. Create a feature branch: `git checkout -b feature/your-feature`
2. Commit changes: `git commit -m "feat: your feature"`
3. Push: `git push origin feature/your-feature`
4. Open a Pull Request

---

## Roadmap

- [ ] Connect frontend dashboard to live backend API
- [ ] JWT authentication for internal team
- [ ] Cert expiry alerts (30-day advance warning emails)
- [ ] Apigee X API integration (auto-create apps via API)
- [ ] Slack notifications alongside email
- [ ] Client self-service cert upload portal

---

*Built by the Client API Team · Drug Price Platform*
