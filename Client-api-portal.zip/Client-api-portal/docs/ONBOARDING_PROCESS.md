# Client Onboarding Process

This document explains the complete end-to-end onboarding process for external clients
who want to consume the Drug Price API.

---

## Process Overview

```
 CLIENT                    API TEAM                  APIGEE TEAM           AKAMAI TEAM
    │                          │                           │                     │
    │── "I want access" ──────►│                           │                     │
    │                          │ Register in portal        │                     │
    │                          │──────────────────────────►│                     │
    │                          │   ✉ Email: "Create creds" │                     │
    │                          │                           │ Create app in       │
    │                          │                           │ Apigee X            │
    │                          │◄── PATCH /apigee-done ────│                     │
    │                          │   ✉ Email: "Collect cert" │                     │
    │◄── "Please send cert" ───│                           │                     │
    │                          │                           │                     │
    │──── Submit cert ─────────►│                          │                     │
    │                          │ PATCH /submit-cert        │                     │
    │                          │────────────────────────────────────────────────►│
    │                          │              ✉ Email: "Please onboard cert"     │
    │                          │                           │                     │ Onboard cert
    │                          │◄──────────────────────────── PATCH /akamai-done─│
    │                          │                           │                     │
    │◄── Deliver credentials ──│                           │                     │
    │                          │ PATCH /go-live            │                     │
    │                          │                           │                     │
    │  ✅ Start consuming APIs  │                           │                     │
```

---

## Step-by-Step

### Step 1 — Client Request

**Who acts:** External client  
**What happens:** Client contacts your team (email, ticket, etc.) saying they want to consume an API.

**In the Portal:**
1. Click **+ New Client** in the top-right of the dashboard
2. Fill in: organization name, domain, technical contact email, API product, environment
3. Click **Create Client & Start Onboarding**

**Automatic result:**
- Client record created in MongoDB with stage `APIGEE_PENDING`
- ✉ Email sent to Apigee team with all client details

---

### Step 2 — Apigee App Creation

**Who acts:** Apigee team  
**What happens:** Apigee team receives the email and creates an app in Apigee X.

**In Apigee X:**
1. Log into Apigee X Console
2. Go to **Apps → Create App**
3. Name: `{org-name}-{env}` e.g. `pharma-corp-prod`
4. Assign API Product: Drug Price API
5. Set environment
6. Generate and note the Client ID

**Call the API (or use Portal):**
```http
PATCH /api/clients/:id/apigee-done
{
  "apigeeAppId": "pharma-corp-prod-001",
  "apigeeClientId": "abc123...",
  "apigeeClientSecretRef": "secrets/pharma-corp/client-secret"
}
```

**Automatic result:**
- Stage advances to `CERT_PENDING`
- ✉ Email sent to internal API team: "Creds done, now collect cert"

---

### Step 3 — mTLS Certificate Collection

**Who acts:** Internal API team (contacts the external client)  
**What happens:** API team emails the client requesting their mTLS certificate.

**Certificate Requirements:**
- Format: PEM / x509
- Key size: 2048-bit minimum (4096 recommended)
- Validity: Minimum 1 year from submission date
- Issuing CA: Must be a trusted Certificate Authority (not self-signed)

**Sample email to client:**
> Hi [Contact Name],
>
> Your Apigee app has been created. To complete the setup, we need your
> mTLS client certificate. Please provide:
> - The certificate in PEM format (.pem or .crt file)
> - Certificate subject (CN)
> - SHA256 fingerprint (optional but recommended)
> - Expiry date
>
> Please reply to this email with the certificate attached or pasted inline.

**Once cert received — call the API:**
```http
PATCH /api/clients/:id/submit-cert
{
  "certPem": "-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----",
  "certSubject": "CN=pharma-corp.com, O=Pharma Corp",
  "certFingerprint": "A3:F1:2B:...",
  "certExpiresAt": "2027-03-01"
}
```

**Automatic result:**
- Stage advances to `AKAMAI_PENDING`
- ✉ Email sent to Akamai team with the full cert PEM included

---

### Step 4 — Akamai Certificate Onboarding

**Who acts:** Akamai team  
**What happens:** Akamai team receives the email and onboards the certificate.

**In Akamai Control Center:**
1. Log in → **Security → Client Certificates**
2. Upload the PEM certificate from the email
3. Associate with the Drug Price API property
4. Note the Akamai ticket ID generated

**Call the API:**
```http
PATCH /api/clients/:id/akamai-done
{
  "akamaiTicketId": "AK-2947",
  "notes": "Onboarded to drug-price-prod property"
}
```

**Result:**
- Stage advances to `AKAMAI_DONE`
- Client is ready to receive credentials

---

### Step 5 — Credential Delivery & Go Live

**Who acts:** Internal API team  
**What happens:** API team delivers credentials to the client and marks them live.

**Deliver to client:**
- Client ID (from Apigee)
- Client Secret (from your secrets manager — never send via unencrypted email)
- API endpoint URLs (OAuth, Member Search, Experience API)
- Link to documentation
- Sandbox/test credentials if applicable

**Mark as live:**
```http
PATCH /api/clients/:id/go-live
```

**Result:**
- Stage: `LIVE`, Status: `ACTIVE`
- Client appears in the "Active & Consuming" count on the dashboard

---

## Certificate Renewal

Certificates must be renewed before expiry. The portal tracks `certExpiresAt` on each client.

**Renewal process:**
1. Set a calendar reminder 30 days before `certExpiresAt`
2. Contact client to submit a new certificate
3. Use `PATCH /api/clients/:id/submit-cert` with the new cert
4. This auto-triggers the Akamai email again for re-onboarding
5. Old cert remains active until Akamai confirms the new one is in place

---

## SLA Targets

| Step                        | Target SLA         |
|-----------------------------|--------------------|
| Apigee app creation         | 1 business day     |
| Client cert submission      | Client-dependent   |
| Akamai cert onboarding      | 2–3 business days  |
| Credential delivery         | Same day as Step 4 |
| **Total onboarding time**   | **~5 business days** (excluding client delays) |
