// src/clients/clients.controller.ts
import {
  Controller,
  Get,
  Post,
  Patch,
  Param,
  Body,
  Query,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ClientsService } from './clients.service';
import { CreateClientDto } from './dto/create-client.dto';
import { SubmitCertDto } from './dto/submit-cert.dto';
import { UpdateApigeeDto, UpdateAkamaiDto } from './dto/update-stages.dto';
import { OnboardingStage } from './schemas/client.schema';

@Controller('api/clients')
export class ClientsController {
  constructor(private readonly clientsService: ClientsService) {}

  // ─────────────────────────────────────────────────────────
  // GET /api/clients
  // Returns all clients. Optionally filter by stage.
  //
  // Query params:
  //   ?stage=APIGEE_PENDING   — filter by onboarding stage
  //
  // Used by: Dashboard, All Clients page
  // ─────────────────────────────────────────────────────────
  @Get()
  async findAll(@Query('stage') stage?: OnboardingStage) {
    if (stage) return this.clientsService.findByStage(stage);
    return this.clientsService.findAll();
  }

  // ─────────────────────────────────────────────────────────
  // GET /api/clients/pipeline
  // Returns count of clients at each onboarding stage.
  // Used by: Dashboard stats cards
  // ─────────────────────────────────────────────────────────
  @Get('pipeline')
  async getPipelineSummary() {
    return this.clientsService.getPipelineSummary();
  }

  // ─────────────────────────────────────────────────────────
  // GET /api/clients/:id
  // Returns a single client by MongoDB ID
  // ─────────────────────────────────────────────────────────
  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.clientsService.findById(id);
  }

  // ─────────────────────────────────────────────────────────
  // POST /api/clients
  // Register a new external client.
  //
  // Body: CreateClientDto
  //
  // Side effects:
  //   ✉ Email → Apigee team: "Create app credentials for this client"
  // ─────────────────────────────────────────────────────────
  @Post()
  @HttpCode(HttpStatus.CREATED)
  async register(@Body() dto: CreateClientDto) {
    return this.clientsService.registerClient(dto);
  }

  // ─────────────────────────────────────────────────────────
  // PATCH /api/clients/:id/apigee-done
  // Apigee team calls this once they've created the app creds.
  //
  // Body: UpdateApigeeDto { apigeeAppId, apigeeClientId, apigeeClientSecretRef }
  //
  // Side effects:
  //   ✉ Email → Internal team: "Creds created, now collect cert from client"
  // ─────────────────────────────────────────────────────────
  @Patch(':id/apigee-done')
  async apigeeCredsCreated(
    @Param('id') id: string,
    @Body() dto: UpdateApigeeDto,
  ) {
    return this.clientsService.confirmApigeeCredsCreated(id, dto);
  }

  // ─────────────────────────────────────────────────────────
  // PATCH /api/clients/:id/submit-cert
  // Client (or internal team on behalf) submits the mTLS certificate.
  //
  // Body: SubmitCertDto { certPem, certSubject, certFingerprint, certExpiresAt }
  //
  // Side effects:
  //   ✉ Email → Akamai team: "Please onboard this cert into mTLS"
  // ─────────────────────────────────────────────────────────
  @Patch(':id/submit-cert')
  async submitCertificate(
    @Param('id') id: string,
    @Body() dto: SubmitCertDto,
  ) {
    return this.clientsService.submitCertificate(id, dto);
  }

  // ─────────────────────────────────────────────────────────
  // PATCH /api/clients/:id/akamai-done
  // Akamai team calls this once the cert is onboarded.
  //
  // Body: UpdateAkamaiDto { akamaiTicketId }
  //
  // No email triggered — internal team manually delivers creds next.
  // ─────────────────────────────────────────────────────────
  @Patch(':id/akamai-done')
  async akamaiDone(
    @Param('id') id: string,
    @Body() dto: UpdateAkamaiDto,
  ) {
    return this.clientsService.confirmAkamaiDone(id, dto);
  }

  // ─────────────────────────────────────────────────────────
  // PATCH /api/clients/:id/go-live
  // Internal team marks client as fully onboarded and live.
  // ─────────────────────────────────────────────────────────
  @Patch(':id/go-live')
  async goLive(@Param('id') id: string) {
    return this.clientsService.goLive(id);
  }
}
