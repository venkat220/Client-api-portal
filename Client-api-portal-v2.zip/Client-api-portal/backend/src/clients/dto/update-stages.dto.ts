// src/clients/dto/update-stages.dto.ts
import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

// ── Called by Apigee team once app credentials are created ──
export class UpdateApigeeDto {
  @IsNotEmpty()
  @IsString()
  apigeeAppId: string; // e.g. "pc-prod-001"

  @IsNotEmpty()
  @IsString()
  apigeeClientId: string;

  @IsNotEmpty()
  @IsString()
  apigeeClientSecretRef: string; // Path/reference in secrets manager — NOT the raw secret value

  @IsOptional()
  @IsString()
  notes?: string;
}

// ── Called by Akamai team once the mTLS cert is onboarded ──
export class UpdateAkamaiDto {
  @IsNotEmpty()
  @IsString()
  akamaiTicketId: string; // e.g. "AK-2947"

  @IsOptional()
  @IsString()
  notes?: string;
}
