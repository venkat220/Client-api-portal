# Email Notifications

This document describes all automated email notifications sent by the API Client Portal backend.

---

## Overview

The portal sends **3 automated emails** at key onboarding milestones.
No manual follow-up is needed — each action in the portal fires the right email
to the right team automatically.

```
New Client Registered
        │
        ▼
✉ EMAIL 1 ──► Apigee Team
   "Please create app credentials"
        │
        ▼ (Apigee team confirms via PATCH /apigee-done)
✉ EMAIL 2 ──► Internal API Team
   "Creds done — now collect mTLS cert from client"
        │
        ▼ (Cert submitted via PATCH /submit-cert)
✉ EMAIL 3 ──► Akamai Team
   "Certificate received — please onboard to mTLS"
        │
        ▼ (Akamai confirms via PATCH /akamai-done)
   → Internal team delivers credentials → Client goes LIVE
```

---

## Email 1 — Apigee App Creation Request

**Sent to:** `APIGEE_TEAM_EMAIL`  
**Triggered by:** `POST /api/clients` (new client registered)  
**Subject:** `[ACTION REQUIRED] Create Apigee App Creds — {Organization Name}`

### Content Includes
- Organization name, domain, technical contact details
- API product and environment required
- Portal client ID (MongoDB ObjectId)
- Step-by-step action checklist:
  1. Log into Apigee X Console
  2. Create a new app for the client
  3. Assign the correct API product
  4. Set environment
  5. Return to portal and enter generated Client ID + App ID
- Deep link back to the client record in the portal

### Purpose
Eliminates the manual email/Slack message the API team previously sent to the Apigee
team after every new client registration.

---

## Email 2 — Apigee Credentials Confirmed

**Sent to:** `INTERNAL_TEAM_EMAIL`  
**Triggered by:** `PATCH /api/clients/:id/apigee-done`  
**Subject:** `[INFO] Apigee Creds Created — {Organization Name} — Awaiting mTLS Cert`

### Content Includes
- Apigee App ID, Client ID, environment
- Next step reminder: contact client to request mTLS certificate
- Certificate format requirements (PEM, trusted CA, 2048-bit min)
- Deep link to client record in portal

### Purpose
Notifies the internal API team that Apigee is done and it's now their job
to chase the client for their mTLS certificate.

---

## Email 3 — Akamai Certificate Onboarding Request

**Sent to:** `AKAMAI_TEAM_EMAIL`  
**Triggered by:** `PATCH /api/clients/:id/submit-cert`  
**Subject:** `[ACTION REQUIRED] Onboard mTLS Certificate — {Organization Name}`

### Content Includes
- Organization name, domain, API product
- Apigee App ID (for correlation)
- Certificate subject DN
- SHA256 fingerprint
- Certificate expiry date
- Full PEM certificate block (ready to copy-paste)
- Step-by-step action checklist:
  1. Log into Akamai Control Center
  2. Navigate to Security → Client Certificates
  3. Upload the PEM certificate
  4. Associate with the correct API property
  5. Reply with Akamai Ticket ID
  6. Update portal once confirmed
- Warning box reminding Akamai team to reply with their ticket number

### Purpose
Eliminates the manual handoff from the API team to the Akamai team.
The Akamai team receives everything they need (including the full cert PEM)
in a single email with no back-and-forth.

---

## SMTP Configuration (Office 365)

The backend uses **Nodemailer** with Office 365 SMTP:

```
Host:     smtp.office365.com
Port:     587
Security: STARTTLS (requireTLS: true)
Auth:     Username + Password
```

### .env Variables Required

```env
SMTP_HOST=smtp.office365.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@yourcompany.com
SMTP_PASS=your-app-password
MAIL_FROM="API Portal <noreply@yourcompany.com>"

APIGEE_TEAM_EMAIL=apigee-admin@yourcompany.com
AKAMAI_TEAM_EMAIL=akamai-team@yourcompany.com
INTERNAL_TEAM_EMAIL=api-team@yourcompany.com
```

### App Password (If MFA Is Enabled)

If your Office 365 account has multi-factor authentication:

1. Go to [https://mysignins.microsoft.com/security-info](https://mysignins.microsoft.com/security-info)
2. Add a sign-in method → **App password**
3. Name it `api-portal-smtp`
4. Copy the generated password into `SMTP_PASS` in your `.env`

---

## Email Delivery Log

Every sent email is recorded on the client document in MongoDB under `emailLog`:

```json
"emailLog": [
  {
    "to": "apigee-admin@yourcompany.com",
    "subject": "[ACTION REQUIRED] Create Apigee App Creds — Pharma Corp",
    "sentAt": "2025-03-10T09:05:23.000Z",
    "type": "APIGEE_CREATION_REQUEST"
  },
  {
    "to": "akamai-team@yourcompany.com",
    "subject": "[ACTION REQUIRED] Onboard mTLS Certificate — Pharma Corp",
    "sentAt": "2025-03-12T14:20:11.000Z",
    "type": "AKAMAI_ONBOARDING_REQUEST"
  }
]
```

This gives you a full audit trail of who was notified and when, visible in the
Activity Log tab of the portal dashboard.

---

## Troubleshooting

| Problem | Likely Cause | Fix |
|---------|-------------|-----|
| `Invalid login` SMTP error | Wrong credentials or MFA blocking | Use App Password |
| `Connection timeout` | Firewall blocking port 587 | Check corporate firewall / allow smtp.office365.com:587 |
| Emails going to spam | `MAIL_FROM` domain not matching SMTP user | Use same domain for both |
| Email not logged on client | Save after email failed silently | Check backend logs for error |
