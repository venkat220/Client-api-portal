// src/clients/dto/update-apigee.dto.ts
import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class UpdateApigeeDto {
  @IsNotEmpty()
  @IsString()
  apigeeAppId: string; // e.g. "pc-prod-001"

  @IsNotEmpty()
  @IsString()
  apigeeClientId: string;

  @IsNotEmpty()
  @IsString()
  apigeeClientSecretRef: string; // Reference to secret in secrets manager, NOT the raw value

  @IsOptional()
  @IsString()
  notes?: string;
}

// src/clients/dto/update-akamai.dto.ts
export class UpdateAkamaiDto {
  @IsNotEmpty()
  @IsString()
  akamaiTicketId: string; // e.g. "AK-2947"

  @IsOptional()
  @IsString()
  notes?: string;
}
