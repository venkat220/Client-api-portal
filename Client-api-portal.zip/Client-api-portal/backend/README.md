# API Client Portal — Backend

NestJS + MongoDB + Office 365 SMTP backend for automating client onboarding
with email notifications to the Apigee and Akamai teams.

---

## Stack

| Layer       | Technology                  |
|-------------|-----------------------------|
| Framework   | NestJS 10                   |
| Database    | MongoDB + Mongoose          |
| Email       | Nodemailer + Office 365 SMTP|
| Validation  | class-validator             |
| Config      | @nestjs/config (.env)       |

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Copy and configure environment variables
cp .env.example .env
# Edit .env with your SMTP credentials, MongoDB URI, and team email addresses

# 3. Start MongoDB (if running locally)
mongod --dbpath ./data/db

# 4. Run in development mode
npm run start:dev

# 5. Server starts at http://localhost:3000
```

---

## Environment Variables (.env)

| Variable              | Description                                      |
|-----------------------|--------------------------------------------------|
| `MONGODB_URI`         | MongoDB connection string                        |
| `SMTP_HOST`           | `smtp.office365.com`                             |
| `SMTP_PORT`           | `587`                                            |
| `SMTP_USER`           | Your Outlook email address                       |
| `SMTP_PASS`           | Your Outlook password / app password             |
| `MAIL_FROM`           | Display name + address for outgoing emails       |
| `INTERNAL_TEAM_EMAIL` | API team inbox                                   |
| `APIGEE_TEAM_EMAIL`   | Apigee admin team inbox                          |
| `AKAMAI_TEAM_EMAIL`   | Akamai team inbox                                |
| `PORTAL_URL`          | URL of your frontend portal (for email links)    |

---

## Email Notification Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                  AUTOMATED EMAIL TRIGGERS                       │
├──────────┬──────────────────────────────┬──────────────────────┤
│  Step    │  Trigger                     │  Email Sent To       │
├──────────┼──────────────────────────────┼──────────────────────┤
│  1       │  POST /api/clients           │  Apigee Team         │
│          │  (new client registered)     │  "Create app creds"  │
├──────────┼──────────────────────────────┼──────────────────────┤
│  2       │  PATCH /:id/apigee-done      │  Internal Team       │
│          │  (Apigee confirms creds)     │  "Collect cert now"  │
├──────────┼──────────────────────────────┼──────────────────────┤
│  3       │  PATCH /:id/submit-cert      │  Akamai Team         │
│          │  (cert received)             │  "Onboard this cert" │
└──────────┴──────────────────────────────┴──────────────────────┘
```

---

## API Reference

### GET /api/clients
Returns all clients sorted by registration date.

**Query params:**
- `?stage=APIGEE_PENDING` — filter by onboarding stage

---

### GET /api/clients/pipeline
Returns count of clients at each stage. Used by the dashboard.

**Response:**
```json
{
  "REQUEST_RECEIVED": 0,
  "APIGEE_PENDING": 2,
  "APIGEE_DONE": 0,
  "CERT_PENDING": 1,
  "CERT_RECEIVED": 0,
  "AKAMAI_PENDING": 1,
  "AKAMAI_DONE": 0,
  "LIVE": 18
}
```

---

### POST /api/clients
Register a new external client. **Triggers email to Apigee team.**

**Body:**
```json
{
  "organizationName": "Pharma Corp",
  "domain": "pharma-corp.com",
  "contactName": "Jane Smith",
  "contactEmail": "jane@pharma-corp.com",
  "apiProduct": "Drug Price API",
  "environment": "Production",
  "notes": "Needs UAT access first"
}
```

---

### PATCH /api/clients/:id/apigee-done
Apigee team calls this once app credentials are created.
**Triggers email to internal team.**

**Body:**
```json
{
  "apigeeAppId": "pc-prod-001",
  "apigeeClientId": "abc123clientid",
  "apigeeClientSecretRef": "secrets/pharma-corp/client-secret",
  "notes": "Standard Drug Price product assigned"
}
```

> ⚠ `apigeeClientSecretRef` should be a reference to your secrets manager
> (AWS Secrets Manager, Azure Key Vault, etc.) — never store raw secrets in MongoDB.

---

### PATCH /api/clients/:id/submit-cert
Submit the client's mTLS certificate. **Triggers email to Akamai team.**

**Body:**
```json
{
  "certPem": "-----BEGIN CERTIFICATE-----\nMIIDXTCC...\n-----END CERTIFICATE-----",
  "certSubject": "CN=pharma-corp.com, O=Pharma Corp, C=US",
  "certFingerprint": "A3:F1:2B:...",
  "certExpiresAt": "2027-03-01"
}
```

---

### PATCH /api/clients/:id/akamai-done
Akamai team calls this once the cert is onboarded.

**Body:**
```json
{
  "akamaiTicketId": "AK-2947",
  "notes": "Cert onboarded to production property"
}
```

---

### PATCH /api/clients/:id/go-live
Mark client as fully onboarded and live.

---

## Onboarding Stages

```
REQUEST_RECEIVED → APIGEE_PENDING → CERT_PENDING → AKAMAI_PENDING → LIVE
                        ↓                                  ↓
                   APIGEE_DONE                        AKAMAI_DONE
```

---

## Project Structure

```
src/
├── main.ts                          # Entry point
├── app.module.ts                    # Root module
├── clients/
│   ├── schemas/
│   │   └── client.schema.ts         # MongoDB schema + enums
│   ├── dto/
│   │   ├── create-client.dto.ts     # New client payload
│   │   ├── submit-cert.dto.ts       # Certificate submission
│   │   └── update-stages.dto.ts     # Apigee + Akamai update payloads
│   ├── clients.controller.ts        # REST endpoints
│   ├── clients.service.ts           # Business logic + email triggers
│   └── clients.module.ts
└── mail/
    ├── mail.service.ts              # Nodemailer + all email templates
    └── mail.module.ts
```

---

## Office 365 SMTP Notes

- Host: `smtp.office365.com`, Port: `587`, STARTTLS
- If using MFA on your account, generate an **App Password** in your
  Microsoft account security settings and use that as `SMTP_PASS`
- For production, consider using a **shared mailbox** or a
  **service account** rather than a personal inbox

---

## Frontend Integration

The frontend dashboard calls these endpoints. Update the `API_BASE_URL`
constant in your HTML/React frontend to point to this backend:

```javascript
const API_BASE_URL = 'http://localhost:3000'; // or your deployed URL
```
