// src/clients/clients.service.ts
import {
  Injectable,
  NotFoundException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Client, ClientDocument, ClientStatus, OnboardingStage } from './schemas/client.schema';
import { CreateClientDto } from './dto/create-client.dto';
import { SubmitCertDto } from './dto/submit-cert.dto';
import { UpdateApigeeDto, UpdateAkamaiDto } from './dto/update-stages.dto';
import { MailService } from '../mail/mail.service';

@Injectable()
export class ClientsService {
  private readonly logger = new Logger(ClientsService.name);

  constructor(
    @InjectModel(Client.name) private clientModel: Model<ClientDocument>,
    private readonly mailService: MailService,
  ) {}

  // ─────────────────────────────────────────────────────────
  // STEP 1 — Register new client
  // → Saves to MongoDB
  // → Fires email to Apigee team to create app credentials
  // ─────────────────────────────────────────────────────────
  async registerClient(dto: CreateClientDto): Promise<ClientDocument> {
    this.logger.log(`Registering new client: ${dto.organizationName}`);

    const client = new this.clientModel({
      ...dto,
      stage: OnboardingStage.APIGEE_PENDING,
      status: ClientStatus.ONBOARDING,
      stageTimestamps: {
        [OnboardingStage.REQUEST_RECEIVED]: new Date(),
        [OnboardingStage.APIGEE_PENDING]: new Date(),
      },
      emailLog: [],
    });

    await client.save();
    this.logger.log(`Client saved: ${client._id}`);

    // 🔔 Trigger email → Apigee team: "Please create app credentials"
    try {
      await this.mailService.sendApigeeCreationRequest(client as any);
      await client.save(); // persist email log entry
    } catch (err) {
      // Email failure should not block the registration — log and continue
      this.logger.error(`Email to Apigee team failed: ${err.message}`);
    }

    return client;
  }

  // ─────────────────────────────────────────────────────────
  // STEP 2 — Apigee team confirms creds are created
  // → Updates MongoDB with Apigee app details
  // → Advances stage to CERT_PENDING
  // → Fires email to internal team: "Now collect cert from client"
  // ─────────────────────────────────────────────────────────
  async confirmApigeeCredsCreated(
    clientId: string,
    dto: UpdateApigeeDto,
  ): Promise<ClientDocument> {
    const client = await this.findById(clientId);

    if (client.stage !== OnboardingStage.APIGEE_PENDING) {
      throw new BadRequestException(
        `Client is not in APIGEE_PENDING stage. Current stage: ${client.stage}`,
      );
    }

    client.apigeeAppId = dto.apigeeAppId;
    client.apigeeClientId = dto.apigeeClientId;
    client.apigeeClientSecretRef = dto.apigeeClientSecretRef;
    client.stage = OnboardingStage.CERT_PENDING;
    client.stageTimestamps = {
      ...client.stageTimestamps,
      [OnboardingStage.APIGEE_DONE]: new Date(),
      [OnboardingStage.CERT_PENDING]: new Date(),
    };
    if (dto.notes) client.notes = dto.notes;

    await client.save();
    this.logger.log(`Apigee creds confirmed for: ${client.organizationName}`);

    // 🔔 Trigger email → Internal team: "Creds done, now collect cert"
    try {
      await this.mailService.sendApigeeCredsConfirmation(client as any);
      await client.save();
    } catch (err) {
      this.logger.error(`Email to internal team failed: ${err.message}`);
    }

    return client;
  }

  // ─────────────────────────────────────────────────────────
  // STEP 3 — Client submits their mTLS certificate
  // → Saves cert details to MongoDB
  // → Advances stage to AKAMAI_PENDING
  // → Fires email to Akamai team: "Please onboard this cert"
  // ─────────────────────────────────────────────────────────
  async submitCertificate(
    clientId: string,
    dto: SubmitCertDto,
  ): Promise<ClientDocument> {
    const client = await this.findById(clientId);

    if (client.stage !== OnboardingStage.CERT_PENDING) {
      throw new BadRequestException(
        `Client is not in CERT_PENDING stage. Current stage: ${client.stage}`,
      );
    }

    client.certPem = dto.certPem;
    client.certSubject = dto.certSubject || null;
    client.certFingerprint = dto.certFingerprint || null;
    client.certExpiresAt = dto.certExpiresAt ? new Date(dto.certExpiresAt) : null;
    client.stage = OnboardingStage.AKAMAI_PENDING;
    client.stageTimestamps = {
      ...client.stageTimestamps,
      [OnboardingStage.CERT_RECEIVED]: new Date(),
      [OnboardingStage.AKAMAI_PENDING]: new Date(),
    };

    await client.save();
    this.logger.log(`Cert received for: ${client.organizationName}`);

    // 🔔 Trigger email → Akamai team: "Please onboard this mTLS cert"
    try {
      await this.mailService.sendAkamaiOnboardingRequest(client as any);
      await client.save();
    } catch (err) {
      this.logger.error(`Email to Akamai team failed: ${err.message}`);
    }

    return client;
  }

  // ─────────────────────────────────────────────────────────
  // STEP 4 — Akamai confirms cert is onboarded
  // → Saves Akamai ticket ID
  // → Advances stage to AKAMAI_DONE
  // → Client can now go live (deliver credentials)
  // ─────────────────────────────────────────────────────────
  async confirmAkamaiDone(
    clientId: string,
    dto: UpdateAkamaiDto,
  ): Promise<ClientDocument> {
    const client = await this.findById(clientId);

    if (client.stage !== OnboardingStage.AKAMAI_PENDING) {
      throw new BadRequestException(
        `Client is not in AKAMAI_PENDING stage. Current stage: ${client.stage}`,
      );
    }

    client.akamaiTicketId = dto.akamaiTicketId;
    client.stage = OnboardingStage.AKAMAI_DONE;
    client.stageTimestamps = {
      ...client.stageTimestamps,
      [OnboardingStage.AKAMAI_DONE]: new Date(),
    };
    if (dto.notes) client.notes = dto.notes;

    await client.save();
    this.logger.log(`Akamai done for: ${client.organizationName} (ticket: ${dto.akamaiTicketId})`);

    return client;
  }

  // ─────────────────────────────────────────────────────────
  // STEP 5 — Mark client as LIVE
  // → Advances to LIVE stage
  // → Status becomes ACTIVE
  // ─────────────────────────────────────────────────────────
  async goLive(clientId: string): Promise<ClientDocument> {
    const client = await this.findById(clientId);

    if (client.stage !== OnboardingStage.AKAMAI_DONE) {
      throw new BadRequestException(
        `Client must complete Akamai onboarding before going live. Current stage: ${client.stage}`,
      );
    }

    client.stage = OnboardingStage.LIVE;
    client.status = ClientStatus.ACTIVE;
    client.stageTimestamps = {
      ...client.stageTimestamps,
      [OnboardingStage.LIVE]: new Date(),
    };

    await client.save();
    this.logger.log(`Client is now LIVE: ${client.organizationName}`);

    return client;
  }

  // ─────────────────────────────────────────────────────────
  // QUERIES
  // ─────────────────────────────────────────────────────────
  async findAll(): Promise<ClientDocument[]> {
    return this.clientModel.find().sort({ createdAt: -1 }).exec();
  }

  async findById(id: string): Promise<ClientDocument> {
    const client = await this.clientModel.findById(id).exec();
    if (!client) throw new NotFoundException(`Client ${id} not found`);
    return client;
  }

  async findByStage(stage: OnboardingStage): Promise<ClientDocument[]> {
    return this.clientModel.find({ stage }).sort({ createdAt: -1 }).exec();
  }

  async getPipelineSummary(): Promise<Record<string, number>> {
    const stages = Object.values(OnboardingStage);
    const summary: Record<string, number> = {};
    for (const stage of stages) {
      summary[stage] = await this.clientModel.countDocuments({ stage });
    }
    return summary;
  }
}
