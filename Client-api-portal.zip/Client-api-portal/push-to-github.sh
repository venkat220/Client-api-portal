#!/bin/bash
# ─────────────────────────────────────────────────────────
# push-to-github.sh
# Run this script to push the entire portal to GitHub.
# Usage: bash push-to-github.sh
# ─────────────────────────────────────────────────────────

set -e  # Exit on any error

REPO_URL="https://github.com/venkat220/Client-api-portal.git"
BRANCH="main"

echo "🚀 Pushing Client API Portal to GitHub..."
echo ""

# Check git is installed
if ! command -v git &> /dev/null; then
  echo "❌ Git is not installed. Please install git first."
  exit 1
fi

# Initialize git if not already a repo
if [ ! -d ".git" ]; then
  echo "📁 Initializing git repository..."
  git init
  git remote add origin $REPO_URL
else
  echo "✅ Git repo already initialized"
  # Make sure remote is set correctly
  git remote set-url origin $REPO_URL 2>/dev/null || git remote add origin $REPO_URL
fi

# Stage everything
echo "📦 Staging all files..."
git add .

# Commit
echo "💾 Committing..."
git commit -m "feat: initial commit — Client API Portal

- Frontend: single-file dashboard (HTML/CSS/JS)
  - Dashboard with pipeline stats
  - Onboarding tracker with 5-step progress
  - API flow tester (OAuth → Member Search → Experience API)
  - Flow viewer / architecture diagram
  - Developer documentation
  - Activity log

- Backend: NestJS + MongoDB + Office 365 SMTP
  - POST /api/clients — register client + email Apigee team
  - PATCH /apigee-done — confirm creds + email internal team
  - PATCH /submit-cert — log cert + email Akamai team
  - PATCH /akamai-done — confirm Akamai onboarding
  - PATCH /go-live — mark client active
  - Full email audit log on each client record

- Docs
  - API_REFERENCE.md
  - EMAIL_NOTIFICATIONS.md
  - ONBOARDING_PROCESS.md"

# Push
echo "⬆  Pushing to $REPO_URL ($BRANCH)..."
git push -u origin $BRANCH

echo ""
echo "✅ Done! Your repo is live at:"
echo "   https://github.com/venkat220/Client-api-portal"
