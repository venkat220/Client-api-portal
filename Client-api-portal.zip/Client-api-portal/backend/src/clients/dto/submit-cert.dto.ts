// src/clients/dto/submit-cert.dto.ts
import { IsDateString, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class SubmitCertDto {
  @IsNotEmpty()
  @IsString()
  certPem: string; // Full PEM content of the client certificate

  @IsOptional()
  @IsString()
  certSubject?: string; // e.g. "CN=pharma-corp.com, O=Pharma Corp"

  @IsOptional()
  @IsString()
  certFingerprint?: string; // SHA256 fingerprint

  @IsOptional()
  @IsDateString()
  certExpiresAt?: string; // ISO date string e.g. "2027-03-01"
}
